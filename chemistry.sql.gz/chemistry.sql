-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 25, 2013 at 02:21 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chemistry`
--
CREATE DATABASE IF NOT EXISTS `chemistry` DEFAULT CHARACTER SET utf8 COLLATE utf8_swedish_ci;
USE `chemistry`;

-- --------------------------------------------------------

--
-- Table structure for table `elements`
--

CREATE TABLE IF NOT EXISTS `elements` (
  `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'atomic number',
  `name` varchar(500) COLLATE utf8_swedish_ci DEFAULT NULL COMMENT 'element name',
  `symbol` tinytext COLLATE utf8_swedish_ci NOT NULL,
  `atomic_weight` int(11) DEFAULT NULL COMMENT 'atomic weight',
  `electrons` int(11) DEFAULT NULL COMMENT 'number of electrons',
  `protons` int(11) DEFAULT NULL COMMENT 'number of protons',
  `neutrons` int(11) DEFAULT NULL COMMENT 'number of neutrons',
  `latin_name` varchar(500) COLLATE utf8_swedish_ci DEFAULT NULL COMMENT 'latin name',
  `groupno` int(11) DEFAULT NULL COMMENT 'group number to which this element belongs',
  `period` int(11) NOT NULL COMMENT 'period number to which this element belongs',
  `density` double NOT NULL COMMENT 'density',
  `mp` double NOT NULL COMMENT 'melting point',
  `bp` double NOT NULL COMMENT 'boiling point',
  `electronegativity` double NOT NULL COMMENT 'Electronagitivity of this element',
  `shc` double NOT NULL COMMENT 'Specific Heat Capacity',
  `abundance` double NOT NULL COMMENT 'Abundance on earth (per 1000 KG)',
  KEY `Id_2` (`Id`,`name`(255),`atomic_weight`,`electrons`,`protons`,`neutrons`,`latin_name`(255),`groupno`,`period`,`density`,`mp`,`bp`,`electronegativity`,`shc`,`abundance`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci AUTO_INCREMENT=119 ;

--
-- Dumping data for table `elements`
--

INSERT INTO `elements` (`Id`, `name`, `symbol`, `atomic_weight`, `electrons`, `protons`, `neutrons`, `latin_name`, `groupno`, `period`, `density`, `mp`, `bp`, `electronegativity`, `shc`, `abundance`) VALUES
(1, 'Hydrogen', 'H', 1, 1, 1, 0, 'the Greek hydro and genes meaning waterforming', 1, 1, 0.00008988, 14.01, 20.28, 2.2, 14.304, 1400),
(2, 'Helium', 'He', 4, 2, 2, 2, 'the Greek- helios meaning sun', 18, 1, 0.0001785, 0.956, 4.22, 0, 5.193, 0.008),
(3, 'Lithium', 'Li', 7, 3, 3, 4, 'the Greek lithos meaning stone', 1, 2, 0.534, 453.69, 1560, 0.98, 3.582, 20),
(4, 'Beryllium', 'Be', 9, 4, 4, 5, 'the Greek name for beryl- beryllo', 2, 2, 1.85, 1560, 2742, 1.57, 1.825, 2.8),
(5, 'Boron', 'B', 11, 5, 5, 6, 'the Arabic buraq- which was the name for borax', 13, 2, 2.34, 2349, 4200, 2.04, 1.026, 10),
(6, 'Carbon', 'C', 12, 6, 6, 6, 'the Latin carbo- meaning charcoal', 14, 2, 2.267, 3800, 4300, 2.55, 0.709, 200),
(7, 'Nitrogen', 'N', 14, 7, 7, 7, 'the Greek nitron and genes meaning nitreforming', 15, 2, 0.0012506, 63.15, 77.36, 3.04, 1.04, 19),
(8, 'Oxygen', 'O', 16, 8, 8, 8, 'the Greek oxy and genes meaning acidforming', 16, 2, 0.001429, 54.36, 90.2, 3.44, 0.918, 461000),
(9, 'Fluorine', 'F', 19, 9, 9, 10, 'the Latin fluere- meaning flow', 17, 2, 0.001696, 53.53, 85.03, 3.98, 0.824, 585),
(10, 'Neon', 'Ne', 20, 10, 10, 10, 'the Greek neos- meaning new', 18, 2, 0.0008999, 24.56, 27.07, 0, 1.03, 0.005),
(11, 'Sodium', 'Na', 23, 11, 11, 12, 'the English word soda (natrium in Latin)[2]', 1, 3, 0.971, 370.87, 1156, 0.93, 1.228, 23600),
(12, 'Magnesium', 'Mg', 24, 12, 12, 12, 'Magnesia- a district of Eastern Thessaly in Greece', 2, 3, 1.738, 923, 1363, 1.31, 1.023, 23300),
(13, 'Aluminium', 'Al', 27, 13, 13, 14, 'the Latin name for alum- alumen meaning bitter salt', 13, 3, 2.698, 933.47, 2792, 1.61, 0.897, 82300),
(14, 'Silicon', 'Si', 28, 14, 14, 14, 'the Latin silex or silicis- meaning flint', 14, 3, 2.3296, 1687, 3538, 1.9, 0.705, 282000),
(15, 'Phosphorus', 'P', 31, 15, 15, 16, 'the Greek phosphoros- meaning bringer of light', 15, 3, 1.82, 317.3, 550, 2.19, 0.769, 1050),
(16, 'Sulfur', 'S', 32, 16, 16, 16, 'Either from the Sanskrit sulvere- or the Latin sulfurium- both names for sulfur[2]', 16, 3, 2.067, 388.36, 717.87, 2.58, 0.71, 350),
(17, 'Chlorine', 'Cl', 35, 17, 17, 18, 'the Greek chloros- meaning greenish yellow', 17, 3, 0.003214, 171.6, 239.11, 3.16, 0.479, 145),
(18, 'Argon', 'Ar', 40, 18, 18, 22, 'the Greek- argos- meaning idle', 18, 3, 0.0017837, 83.8, 87.3, 0, 0.52, 3.5),
(19, 'Potassium', 'K', 39, 19, 19, 20, 'the English word potash (kalium in Latin)[2]', 1, 4, 0.862, 336.53, 1032, 0.82, 0.757, 20900),
(20, 'Calcium', 'Ca', 40, 20, 20, 20, 'the Latin calx meaning lime', 2, 4, 1.54, 1115, 1757, 1, 0.647, 41500),
(21, 'Scandium', 'Sc', 45, 21, 21, 24, 'Scandinavia (with the Latin name Scandia)', 3, 4, 2.989, 1814, 3109, 1.36, 0.568, 22),
(22, 'Titanium', 'Ti', 48, 22, 22, 26, 'Titans- the sons of the Earth goddess of Greek mythology', 4, 4, 4.54, 1941, 3560, 1.54, 0.523, 5650),
(23, 'Vanadium', 'V', 51, 23, 23, 28, 'Vanadis- an old Norse name for the Scandinavian goddess Freyja', 5, 4, 6.11, 2183, 3680, 1.63, 0.489, 120),
(24, 'Chromium', 'Cr', 52, 24, 24, 28, 'the Greek chroma- meaning colour', 6, 4, 7.15, 2180, 2944, 1.66, 0.449, 102),
(25, 'Manganese', 'Mn', 55, 25, 25, 30, 'Either the Latin magnes- meaning magnet or from the black magnesium oxide- magnesia nigra', 7, 4, 7.44, 1519, 2334, 1.55, 0.479, 950),
(26, 'Iron', 'Fe', 56, 26, 26, 30, 'the AngloSaxon name iren (ferrum in Latin)', 8, 4, 7.874, 1811, 3134, 1.83, 0.449, 56300),
(27, 'Cobalt', 'Co', 59, 27, 27, 32, 'the German word kobald- meaning goblin', 9, 4, 8.86, 1768, 3200, 1.88, 0.421, 25),
(28, 'Nickel', 'Ni', 59, 28, 28, 31, 'the shortened of the German kupfernickel meaning either devils copper or St. Nicholass copper', 10, 4, 8.912, 1728, 3186, 1.91, 0.444, 84),
(29, 'Copper', 'Cu', 64, 29, 29, 35, 'the Old English name coper in turn derived from the Latin Cyprium aes- meaning a metal from, Cyprus', 11, 4, 8.96, 1357.77, 2835, 1.9, 0.385, 60),
(30, 'Zinc', 'Zn', 65, 30, 30, 35, 'the German- zinc- which may in turn be derived from the Persian word sing- meaning stone', 12, 4, 7.134, 692.88, 1180, 1.65, 0.388, 70),
(31, 'Gallium', 'Ga', 70, 31, 31, 39, 'France (with the Latin name Gallia)', 13, 4, 5.907, 302.9146, 2477, 1.81, 0.371, 19),
(32, 'Germanium', 'Ge', 73, 32, 32, 41, 'Germany (with the Latin name Germania)', 14, 4, 5.323, 1211.4, 3106, 2.01, 0.32, 1.5),
(33, 'Arsenic', 'As', 75, 33, 33, 42, 'the Greek name arsenikon for the yellow pigment orpiment', 15, 4, 5.776, 1090, 887, 2.18, 0.329, 1.8),
(34, 'Selenium', 'Se', 79, 34, 34, 45, 'Moon (with the Greek name selene)', 16, 4, 4.809, 453, 958, 2.55, 0.321, 0.05),
(35, 'Bromine', 'Br', 80, 35, 35, 45, 'the Greek bromos meaning stench', 17, 4, 3.122, 265.8, 332, 2.96, 0.474, 2.4),
(36, 'Krypton', 'Kr', 84, 36, 36, 48, 'the Greek kryptos- meaning hidden', 18, 4, 0.003733, 115.79, 119.93, 3, 0.248, 0.000001),
(37, 'Rubidium', 'Rb', 85, 37, 37, 48, 'the Latin rubidius- meaning deepest red', 1, 5, 1.532, 312.46, 961, 0.82, 0.363, 90),
(38, 'Strontium', 'Sr', 88, 38, 38, 50, 'Strontian- a small town in Scotland', 2, 5, 2.64, 1050, 1655, 0.95, 0.301, 370),
(39, 'Yttrium', 'Y', 89, 39, 39, 50, 'Ytterby- Sweden', 3, 5, 4.469, 1799, 3609, 1.22, 0.298, 33),
(40, 'Zirconium', 'Zr', 91, 40, 40, 51, 'the Persian zargun- meaning gold coloured', 4, 5, 6.506, 2128, 4682, 1.33, 0.278, 165),
(41, 'Niobium', 'Nb', 93, 41, 41, 52, 'Niobe- daughter of king Tantalus from Greek mythology', 5, 5, 8.57, 2750, 5017, 1.6, 0.265, 20),
(42, 'Molybdenum', 'Mo', 96, 42, 42, 54, 'the Greek molybdos meaning lead', 6, 5, 10.22, 2896, 4912, 2.16, 0.251, 1.2),
(43, 'Technetium', 'Tc', 98, 43, 43, 55, 'the Greek tekhnetos meaning artificial', 7, 5, 11.5, 2430, 4538, 1.9, 0, 0.00001),
(44, 'Ruthenium', 'Ru', 101, 44, 44, 57, 'Russia (with the Latin name Ruthenia)', 8, 5, 12.37, 2607, 4423, 2.2, 0.238, 0.001),
(45, 'Rhodium', 'Rh', 103, 45, 45, 58, 'the Greek rhodon- meaning rose coloured', 9, 5, 12.41, 2237, 3968, 2.28, 0.243, 0.001),
(46, 'Palladium', 'Pd', 106, 46, 46, 60, 'the then recentlydiscovered asteroid Pallas- considered a planet at the time', 10, 5, 12.02, 1828.05, 3236, 2.2, 0.244, 0.015),
(47, 'Silver', 'Ag', 108, 47, 47, 61, 'the AngloSaxon name siolfur (argentum in Latin)[2]', 11, 5, 10.501, 1234.93, 2435, 1.93, 0.235, 0.075),
(48, 'Cadmium', 'Cd', 112, 48, 48, 64, 'the Latin name for the mineral calmine- cadmia', 12, 5, 8.69, 594.22, 1040, 1.69, 0.232, 0.159),
(49, 'Indium', 'In', 115, 49, 49, 66, 'the Latin indicium- meaning violet or indigo', 13, 5, 7.31, 429.75, 2345, 1.78, 0.233, 0.25),
(50, 'Tin', 'Sn', 119, 50, 50, 69, 'the AngloSaxon word tin (stannum in Latin- meaning hard)', 14, 5, 7.287, 505.08, 2875, 1.96, 0.228, 2.3),
(51, 'Antimony', 'Sb', 122, 51, 51, 71, 'the Greek anti  monos- meaning not alone (stibium in Latin)', 15, 5, 6.685, 903.78, 1860, 2.05, 0.207, 0.2),
(52, 'Tellurium', 'Te', 128, 52, 52, 76, 'Earth- the third planet on solar system (with the Latin word tellus)', 16, 5, 6.232, 722.66, 1261, 2.1, 0.202, 0.001),
(53, 'Iodine', 'I', 127, 53, 53, 74, 'the Greek iodes meaning violet', 17, 5, 4.93, 386.85, 457.4, 2.66, 0.214, 0.45),
(54, 'Xenon', 'Xe', 131, 54, 54, 77, 'the Greek xenos meaning stranger', 18, 5, 0.005887, 161.4, 165.03, 2.6, 0.158, 0.00001),
(55, 'Caesium', 'Cs', 133, 55, 55, 78, 'the Latin caesius- meaning sky blue', 1, 6, 1.873, 301.59, 944, 0.79, 0.242, 3),
(56, 'Barium', 'Ba', 137, 56, 56, 81, 'the Greek barys- meaning heavy', 2, 6, 3.594, 1000, 2170, 0.89, 0.204, 425),
(57, 'Lanthanum', 'La', 139, 57, 57, 82, '', 0, 0, 6.145, 1193, 3737, 1.1, 0.195, 39),
(58, 'Cerium', 'Ce', 140, 58, 58, 82, '', 0, 0, 6.77, 1068, 3716, 1.12, 0.192, 66.5),
(59, 'Praseodymium', 'Pr', 141, 59, 59, 82, '', 0, 0, 6.773, 1208, 3793, 1.13, 0.193, 9.2),
(60, 'Neodymium', 'Nd', 144, 60, 60, 84, '', 0, 0, 7.007, 1297, 3347, 1.14, 0.19, 41.5),
(61, 'Promethium', 'Pm', 145, 61, 61, 84, '', 0, 0, 7.26, 1315, 3273, 1.13, 0, 0.00001),
(62, 'Samarium', 'Sm', 150, 62, 62, 88, '', 0, 0, 7.52, 1345, 2067, 1.17, 0.197, 7.05),
(63, 'Europium', 'Eu', 152, 63, 63, 89, '', 0, 0, 5.243, 1099, 1802, 1.2, 0.182, 2),
(64, 'Gadolinium', 'Gd', 157, 64, 64, 93, '', 0, 0, 7.895, 1585, 3546, 1.2, 0.236, 6.2),
(65, 'Terbium', 'Tb', 159, 65, 65, 94, '', 0, 0, 8.229, 1629, 3503, 1.2, 0.182, 1.2),
(66, 'Dysprosium', 'Dy', 163, 66, 66, 97, '', 0, 0, 8.55, 1680, 2840, 1.22, 0.17, 5.2),
(67, 'Holmium', 'Ho', 165, 67, 67, 98, '', 0, 0, 8.795, 1734, 2993, 1.23, 0.165, 1.3),
(68, 'Erbium', 'Er', 167, 68, 68, 99, '', 0, 0, 9.066, 1802, 3141, 1.24, 0.168, 3.5),
(69, 'Thulium', 'Tm', 169, 69, 69, 100, '', 0, 0, 9.321, 1818, 2223, 1.25, 0.16, 0.52),
(70, 'Ytterbium', 'Yb', 173, 70, 70, 103, '', 0, 0, 6.965, 1097, 1469, 1.1, 0.155, 3.2),
(71, 'Lutetium', 'Lu', 175, 71, 71, 104, '', 0, 0, 9.84, 1925, 3675, 1.27, 0.154, 0.8),
(72, 'Hafnium', 'Hf', 178, 72, 72, 106, '', 0, 0, 13.31, 2506, 4876, 1.3, 0.144, 3),
(73, 'Tantalum', 'Ta', 181, 73, 73, 108, '', 0, 0, 16.654, 3290, 5731, 1.5, 0.14, 2),
(74, 'Tungsten', 'W', 184, 74, 74, 110, '', 0, 0, 19.25, 3695, 5828, 2.36, 0.132, 1.3),
(75, 'Rhenium', 'Re', 186, 75, 75, 111, '', 0, 0, 21.02, 3459, 5869, 1.9, 0.137, 0.00001),
(76, 'Osmium', 'Os', 190, 76, 76, 114, '', 0, 0, 22.61, 3306, 5285, 2.2, 0.13, 0.002),
(77, 'Iridium', 'Ir', 192, 77, 77, 115, '', 0, 0, 22.56, 2719, 4701, 2.2, 0.131, 0.001),
(78, 'Platinum', 'Pt', 195, 78, 78, 117, '', 0, 0, 21.46, 2041.4, 4098, 2.28, 0.133, 0.005),
(79, 'Gold', 'Au', 197, 79, 79, 118, '', 0, 0, 19.282, 1337.33, 3129, 2.54, 0.129, 0.004),
(80, 'Mercury', 'Hg', 201, 80, 80, 121, '', 0, 0, 13.5336, 234.43, 629.88, 2, 0.14, 0.085),
(81, 'Thallium', 'Tl', 204, 81, 81, 123, '', 0, 0, 11.85, 577, 1746, 1.62, 0.129, 0.85),
(82, 'Lead', 'Pb', 207, 82, 82, 125, '', 0, 0, 11.342, 600.61, 2022, 1.87, 0.129, 14),
(83, 'Bismuth', 'Bi', 209, 83, 83, 126, '', 0, 0, 9.807, 544.7, 1837, 2.02, 0.122, 0.009),
(84, 'Polonium', 'Po', 209, 84, 84, 125, '', 0, 0, 9.32, 527, 1235, 2, 0, 0.00001),
(85, 'Astatine', 'At', 210, 85, 85, 125, '', 0, 0, 7, 575, 610, 2.2, 0, 0.00001),
(86, 'Radon', 'Rn', 222, 86, 86, 136, '', 0, 0, 0.00973, 202, 211.3, 2.2, 0.094, 0.00001),
(87, 'Francium', 'Fr', 223, 87, 87, 136, '', 0, 0, 1.87, 300, 950, 0.7, 0, 0.00001),
(88, 'Radium', 'Ra', 226, 88, 88, 138, '', 0, 0, 5.5, 973, 2010, 0.9, 2.2, 0.00001),
(89, 'Actinium', 'Ac', 227, 89, 89, 138, '', 0, 0, 10.07, 1323, 3471, 1.1, 0.12, 0.00001),
(90, 'Thorium', 'Th', 232, 90, 90, 142, '', 0, 0, 11.72, 2115, 5061, 1.3, 0.113, 9.6),
(91, 'Protactinium', 'Pa', 231, 91, 91, 140, '', 0, 0, 15.37, 1841, 4300, 1.5, 0, 0.00001),
(92, 'Uranium', 'U', 238, 92, 92, 146, '', 0, 0, 18.95, 1405.3, 4404, 1.38, 0.116, 2.7),
(93, 'Neptunium', 'Np', 237, 93, 93, 144, '', 0, 0, 20.45, 917, 4273, 1.36, 0, 0.00001),
(94, 'Plutonium', 'Pu', 244, 94, 94, 150, '', 0, 0, 19.84, 912.5, 3501, 1.28, 0, 0.00001),
(95, 'Americium', 'Am', 243, 95, 95, 148, '', 0, 0, 13.69, 1449, 2880, 1.13, 0, 0.00001),
(96, 'Curium', 'Cm', 247, 96, 96, 151, '', 0, 0, 13.51, 1613, 3383, 1.28, 0, 0.00001),
(97, 'Berkelium', 'Bk', 247, 97, 97, 150, '', 0, 0, 14.79, 1259, 2900, 1.3, 0, 0.00001),
(98, 'Californium', 'Cf', 251, 98, 98, 153, '', 0, 0, 15.1, 1173, 1743, 1.3, 0, 0.00001),
(99, 'Einsteinium', 'Es', 252, 99, 99, 153, '', 0, 0, 8.84, 1133, 1269, 1.3, 0, 0),
(100, 'Fermium', 'Fm', 257, 100, 100, 157, '', 1125, 0, 0, 0, 0, 1.3, 0, 0),
(101, 'Mendelevium', 'Md', 258, 101, 101, 157, '', 1100, 0, 0, 0, 0, 1.3, 0, 0),
(102, 'Nobelium', 'No', 259, 102, 102, 157, '', 1100, 0, 0, 0, 0, 1.3, 0, 0),
(103, 'Lawrencium', 'Lr', 262, 103, 103, 159, '', 1900, 0, 0, 0, 0, 1.3, 0, 0),
(104, 'Rutherfordium', 'Rf', 267, 104, 104, 163, '23.2', 2400, 5800, 0, 0, 0, 0, 0, 0),
(105, 'Dubnium', 'Db', 268, 105, 105, 163, '29.3', 0, 0, 0, 0, 0, 0, 0, 0),
(106, 'Seaborgium', 'Sg', 269, 106, 106, 163, '35', 0, 0, 0, 0, 0, 0, 0, 0),
(107, 'Bohrium', 'Bh', 270, 107, 107, 163, '37.1', 0, 0, 0, 0, 0, 0, 0, 0),
(108, 'Hassium', 'Hs', 269, 108, 108, 161, '40.7', 0, 0, 0, 0, 0, 0, 0, 0),
(109, 'Meitnerium', 'Mt', 278, 109, 109, 169, '37.4', 0, 0, 0, 0, 0, 0, 0, 0),
(110, 'Darmstadtium', 'Ds', 281, 110, 110, 171, '34.8', 0, 0, 0, 0, 0, 0, 0, 0),
(111, 'Roentgenium', 'Rg', 281, 111, 111, 170, '28.7', 0, 0, 0, 0, 0, 0, 0, 0),
(112, 'Copernicium', 'Cn', 285, 112, 112, 173, '23.7', 0, 0, 0, 0, 0, 0, 0, 0),
(113, 'Ununtrium', 'Uut', 286, 113, 113, 173, '16', 700, 1400, 0, 0, 0, 0, 0, 0),
(114, 'Flerovium', 'Fl', 289, 114, 114, 175, '14', 340, 420, 0, 0, 0, 0, 0, 0),
(115, 'Ununpentium', 'Uup', 288, 115, 115, 173, '13.5', 700, 1400, 0, 0, 0, 0, 0, 0),
(116, 'Livermorium', 'Lv', 293, 116, 116, 177, '12.9', 709, 1085, 0, 0, 0, 0, 0, 0),
(117, 'Ununseptium', 'Uus', 294, 117, 117, 177, '7.2', 673, 823, 0, 0, 0, 0, 0, 0),
(118, 'Ununoctium', 'Uuo', 294, 118, 118, 176, '5', 258, 263, 0, 0, 0, 0, 0, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
